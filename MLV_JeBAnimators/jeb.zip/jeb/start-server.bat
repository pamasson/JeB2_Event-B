node server.js
pause
