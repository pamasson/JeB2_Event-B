// PAM : valuation for the constants whose possible values were not guessed by JeB
$cst.Ventilation = $B.SetExtension("PCV", "PSV");
$cst.StartUp = "StartUp";
$cst.Start = "Start";
$cst.SelfTest = "SelfTest";
$cst.Menu = "Menu";
$cst.Settings = "Settings";
// /*
$cst.Off = "Off";
$cst.PCV = "PCV";
$cst.PSV = "PSV";
$cst.ModesG = $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation);
// */

// /*
$cst.batteryRange = $B.UpTo($B('0'), $B('10')); // limited values for animation
// */
$cst.Modes = "Modes";
$cst.possTransG = $B.SetExtension(
    $B.Pair($B.TRUE, 
        $B.SetExtension(
            $B.Pair($cst.Start , $cst.Menu ),
            $B.Pair($cst.Start , $cst.SelfTest ),
            $B.Pair($cst.Menu , $cst.PCV ),
            $B.Pair($cst.Menu , $cst.PSV ),
            $B.Pair($cst.Menu , $cst.Settings ),
            $B.Pair($cst.Off , $cst.PCV ),
            $B.Pair($cst.Off , $cst.PSV ),
            $B.Pair($cst.Off , $cst.StartUp ),
            $B.Pair($cst.PCV , $cst.Menu ),
            $B.Pair($cst.PCV , $cst.PCV ),
            $B.Pair($cst.PCV , $cst.PSV ),
            $B.Pair($cst.PCV , $cst.Settings ),
            $B.Pair($cst.PSV , $cst.Menu ),
            $B.Pair($cst.PSV , $cst.PCV ),
            $B.Pair($cst.PSV , $cst.PSV ),
            $B.Pair($cst.PSV , $cst.Settings ),
            $B.Pair($cst.SelfTest , $cst.Menu ),
            $B.Pair($cst.SelfTest , $cst.SelfTest ),
            $B.Pair($cst.Settings , $cst.Menu ),
            $B.Pair($cst.Settings , $cst.PCV ),
            $B.Pair($cst.Settings , $cst.PSV ),
            $B.Pair($cst.StartUp , $cst.Start ),
            $B.Pair($cst.StartUp , $cst.PCV ),
            $B.Pair($cst.StartUp , $cst.PSV ),
        )
    ),
    $B.Pair($B.FALSE, $B.CartesianProduct($cst.ModesG, $B.SetExtension($cst.Off)))
);

// 4_MCH_ContSM
$cst.FailSafe = "FailSafe";
$cst.VentilationOff = "VentilationOff";
$cst.ModesC = $B.SetExtension($cst.StartUp, $cst.SelfTest, $cst.FailSafe, $cst.VentilationOff, $cst.Off, $cst.PCV, $cst.PSV);

$cst.possTransC = $B.SetExtension(
    $B.Pair($B.TRUE, 
        $B.SetExtension(
            $B.Pair($cst.StartUp , $cst.SelfTest ),
            $B.Pair($cst.StartUp , $cst.FailSafe ),
            $B.Pair($cst.SelfTest , $cst.FailSafe ),
            $B.Pair($cst.SelfTest , $cst.VentilationOff ),
            $B.Pair($cst.PSV , $cst.FailSafe ),
            $B.Pair($cst.PSV , $cst.PCV ),
            $B.Pair($cst.PSV , $cst.VentilationOff ),
            $B.Pair($cst.PCV , $cst.FailSafe ),
            $B.Pair($cst.PCV , $cst.PSV ),
            $B.Pair($cst.PCV , $cst.VentilationOff ),
            $B.Pair($cst.Off , $cst.StartUp ),
            $B.Pair($cst.VentilationOff , $cst.FailSafe ),
            $B.Pair($cst.VentilationOff , $cst.PSV ),
            $B.Pair($cst.VentilationOff , $cst.PCV )
        )
    ),
    $B.Pair($B.FALSE,
        $B.SetExtension( 
            $B.Pair($cst.StartUp , $cst.Off ),
            $B.Pair($cst.SelfTest , $cst.Off ),
            $B.Pair($cst.FailSafe , $cst.Off ),
            $B.Pair($cst.PSV , $cst.Off ),
            $B.Pair($cst.PCV , $cst.Off ),
            $B.Pair($cst.VentilationOff , $cst.Off )
        )
    )
);

/*
Enumeration of the possible Controller transitions as computed by ProB

{(FALSE↦{(StartUp↦Off),(SelfTest↦Off),(FailSafe↦Off),(PSV↦Off),(PCV↦Off),(VentilationOff↦Off)}),
(TRUE↦{
    (StartUp↦SelfTest),
    (StartUp↦FailSafe),
    (SelfTest↦FailSafe),
    (SelfTest↦VentilationOff),
    (PSV↦FailSafe),
    (PSV↦PCV),
    (PSV↦VentilationOff),
    (PCV↦FailSafe),
    (PCV↦PSV),
    (PCV↦VentilationOff),
    (Off↦StartUp),
    (VentilationOff↦FailSafe),
    (VentilationOff↦PSV),
    (VentilationOff↦PCV)}
)
}
*/


/*
Enumeration of the possible GUI transitions as computed by ProB

{
(FALSE↦{(Start↦Off),(Menu↦Off),(Off↦Off),(PCV↦Off),(PSV↦Off),
    (SelfTest↦Off),(Settings↦Off),(StartUp↦Off)}),
(TRUE↦{
    (Start↦Menu),
    (Start↦SelfTest),
    (Menu↦PCV),
    (Menu↦PSV),
    (Menu↦Settings),
    (Off↦PCV),
    (Off↦PSV),
    (Off↦StartUp),
    (PCV↦Menu),
    (PCV↦PCV),
    (PCV↦PSV),
    (PCV↦Settings),
    (PSV↦Menu),
    (PSV↦PCV),
    (PSV↦PSV),
    (PSV↦Settings),
    (SelfTest↦Menu),
    (SelfTest↦SelfTest),
    (Settings↦Menu),
    (Settings↦PCV),
    (Settings↦PSV),
    (StartUp↦Start),
    (StartUp↦PCV),
    (StartUp↦PSV)}
)
}
*/
