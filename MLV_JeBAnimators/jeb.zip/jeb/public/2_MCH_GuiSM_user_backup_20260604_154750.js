// Auto-generated function: argument generator

var get_modeg = function( eventId ) {
    if (eventId == $evt.e3) {
        return $B.setUnion($B.SetExtension($cst.Start), $cst.Ventilation).anyMember();
    }
    if (eventId == $evt.e5) {
        return $B.SetExtension($cst.Off, $cst.StartUp).anyMember();
        // PAM: OK or so : random choice among the possible values
    }
    if (eventId == $evt.e11) {
        return $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Menu)).anyMember();
    }
    if (eventId == $evt.e12) {
        return $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Menu)).anyMember();
    }
    if (eventId == $evt.e13) {
        return $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Settings)).anyMember();
    }
    if (eventId == $evt.e14) {
        return $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation).anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }
    if (eventId == $evt.e15) {
        return $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation).anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }
    if (eventId == $evt.e16) {
        return $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation).anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }
};


// Auto-generated function: argument generator
var get_modegp = function( eventId ) {
    if (eventId == $evt.e14) {
        return $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation).anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }
};

//var stepValue=get_step($evt.e15);
//var stepValue=0;

var stepVal = 0;

// Auto-generated function: argument generator
var get_step = function( eventId ) {
    if (eventId == $evt.e15) {
        // PAM: in the model step : NAT1. I limit it to values 1..10, 
        // to get a simulation close to ProB. 
        //return $B.UpTo($B('1'), $B('3')).anyMember();
//        stepVal = $B.UpTo($B('1'), $B('3')).anyMember();
        return stepVal;
        //return $B.UpTo($B('1'), $B('3')).anyMember();
        //return $B('1');
        //return Math.ceil(Math.random()*5);
    }
};



// Auto-generated function: argument generator
var get_l = function( eventId ) {
    if (eventId == $evt.e15) {
        // PAM: conform to model: returns a random value chosen within the batteryRange
        //return $cst.batteryRange.anyMember();
        // PAM: Too big in practice. Restricted to values 0..11 to match the ProB animation
        //return $B.UpTo($B('0'), $B('3')).anyMember();
        //if ($var.batFail.value == true)
        //    return $var.batLev.value;
        // 
        // 1. generate a new step value at random
        stepVal = $B.UpTo($B('1'), $B('3')).anyMember();

        // grd2 : batFail=TRUE ⇒ l=batLev
        if ($var.batFail.value==true)
            return $var.batLev.value;
        //grd3 : onAC=TRUE ∧ batFail=FALSE ⇔ l=batLev+step
        if ($var.onAC.value==true && $var.batFail.value==false)
            return $var.batLev.value+stepVal;
        else
            return stepVal;
        return stepVal;
        //grd4 : onAC=FALSE ∧ batFail=FALSE ⇔ l=max({0,batLev−step})
        if ($var.onAC.value==false && $var.batFail.value==false) {
            diff = $var.batLev.value-stepVal;
            if (diff > 0)
                return diff;
            return 0;
        }
        else
            return stepVal;
        //    return ($var.batLev.value-stepVal>0 ? $var.batLev.value-stepVal : 0);
        
    
        return stepVal;

        //return $B.UpTo($B('0'), $B('3')).anyMember();
    }
};

// Auto-generated function: argument generator
var get_batf = function( eventId ) {
    if (eventId == $evt.e15) {
        return $B.BOOL.anyMember();
        // PAM/ this one is OK
    }
};

////////////////////////////////////////////////////////////////////////////
// GUI_SM.js
// Création du canvas avec Fabric.js
//const canvas = $anim.canvas;



class State {
    constructor(name, left, top, width = 50, height = 50, textColor = 'black', fontSize = 12, fillColor = 'lightGrey', lineColor = 'black', lineWidth = 2) {
        this.name = name;
        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
        this.textColor = textColor;
        this.fontSize = fontSize;
        this.fillColor = fillColor;
        this.lineColor = lineColor;
        this.lineWidth = lineWidth;
    }
}

function addState(state) {    
    canvas.add(
        new fabric.Rect({
            left: state.left,
            top: state.top,
            width: state.width,
            height: state.height,
            fill: state.fillColor,
            stroke: state.lineColor,
            strokeWidth: state.lineWidth,
            selectable: false
        })
    );
    canvas.add(new fabric.Text(state.name, {
            left: state.left+state.lineWidth + 5,
            top: state.top+(state.height-state.fontSize)/2,
            fontSize: state.fontSize,
            fill: state.textColor,
    }));
}    

function addStates(... states) {
    for (s of states)  
        addState(s);
}

function lightState(state, color='GreenYellow', textColor='DarkGreen') {
        canvas.add(
        new fabric.Rect({
            left: state.left,
            top: state.top,
            width: state.width,
            height: state.height,
            fill: color,
            stroke: state.lineColor,
            strokeWidth: state.lineWidth,
            selectable: false
        })
    );
    canvas.add(new fabric.Text(state.name, {
            left: state.left+state.lineWidth + 5,
            top: state.top+(state.height-state.fontSize)/2,
            fontSize: state.fontSize,
            fill: textColor,
            fontWeight: 'bold',
    }));
}

function unlightState(state) {
    addState(state);
}

class Transition {
    constructor(from, to, midpoint, nbEndPoints = 1, color = 'black', headSize = 10, thickness = 2, opacity = 1) {
        this.from = from;
        this.to = to;
        this.midpoint = midpoint;
        this.nbEndPoints = nbEndPoints;
        this.color = color;
        this.headSize = headSize;
        this.thickness = thickness;
        this.opacity = opacity;
    }
} 

function curveLink(fromState, toState, midpoint, fromConnect='RIGHT', toConnect='LEFT') {
    link(fromState, toState, fromConnect, toConnect, midpoint);
}

function link(fromState, toState, fromConnect='RIGHT', toConnect='LEFT', midpoint=null, nbEndPoints=1) {
    var fromcp=new fabric.Point(), tocp=new fabric.Point(); // cp = connect point. These variables store the coordinates of the connection points

    // from connect point coordinates
    if (fromConnect==='RIGHT') {
        fromcp.x = fromState.left+fromState.width;
        fromcp.y = fromState.top+fromState.height/2;
    }
    else if (fromConnect==='LEFT') {
        fromcp.x = fromState.left;
        fromcp.y = fromState.top+fromState.height/2;
    }
    else if (fromConnect==='UP') {
        fromcp.x = fromState.left+fromState.width/2;
        fromcp.y = fromState.top;
    }
    else if (fromConnect==='DOWN') {
        fromcp.x = fromState.left+fromState.width/2;
        fromcp.y = fromState.top+fromState.height;
    }
    
    // to connect point coordinates
    if (toConnect==='RIGHT') {
        tocp.x = toState.left+toState.width;
        tocp.y = toState.top+toState.height/2;
    }
    else if (toConnect==='LEFT') {
        tocp.x = toState.left;
        tocp.y = toState.top+toState.height/2;
    }
    else if (toConnect==='UP') {
        tocp.x = toState.left+toState.width/2;
        tocp.y = toState.top;
    }
    else if (toConnect==='DOWN') {
        tocp.x = toState.left+toState.width/2;
        tocp.y = toState.top+toState.height;
    }

//    var trans = new Transition(fromcpx, fromcpy, tocpx, tocpy, bidir);
    var trans = new Transition(fromcp, tocp, midpoint, nbEndPoints);
    addTransition(trans);
}
function bilink(fromState, toState, fromConnect='RIGHT', toConnect='LEFT', midpoint=null) {
    link(fromState, toState, fromConnect, toConnect, midpoint, 2);
}

function selfLoop(state, fromConnect='UP', toConnect='RIGHT') {
    var midPoint = {x:state.left+2*state.width, y: state.top-0.5*state.height};
    link(state, state, fromConnect, toConnect, midPoint, 0);
}



function addTransition(trans) {
    // adding the line
    var line2 = [];
    //var line2 = new fabric.Path();


//    var line = new fabric.Path('M 100 100 Q 200, 50, 300, 100', { fill: '', stroke: 'black', objectCaching: false });
    var start = `M ${trans.from.x} ${trans.from.y}`;
    var mid = trans.midpoint==null ? '' : ` Q ${trans.midpoint.x} ${trans.midpoint.y}`
    var end = ` ${trans.to.x} ${trans.to.y}`;

    var curve = start + mid + end;
    
    canvas.add(
        new fabric.Path(curve, {
            fill: '',
            stroke: trans.color,
            strokeWidth: trans.thickness,
            opacity: trans.opacity,
        })
    );
    // Adding the endpoints
    if (trans.nbEndPoints > 0)
        canvas.add( // Endpoint : to
            new fabric.Circle({
                left: trans.to.x,
                top: trans.to.y,
                radius: trans.headSize,
                fill: trans.color,
                originX: 'center', 
                originY: 'center',
                opacity: trans.opacity,
            })
        );
    if (trans.nbEndPoints > 1) 
        canvas.add( // Endpoint : from
            new fabric.Circle({
                left: trans.from.x,
                top: trans.from.y,
                radius: trans.headSize,
                fill: trans.color,
                originX: 'center', 
                originY: 'center',
                opacity: trans.opacity,
            })
        );
}

var defy = 225; // default Y 
var Off = new State('Off', 50, defy);
var StartUp = new State('StartUp', 200, defy);
var Start = new State('Start', 350, defy);
var SelfTest = new State('SelfTest', 500, 275);
var Menu = new State('Menu', 750, defy);
var Settings = new State('Settings', 875, defy);
var PSV = new State('PSV', 1000, 50);
var PCV = new State('PCV', 1000, 350);
var previousState = null;

var stateVar = {'Off': Off, 'StartUp': StartUp, 'Start':Start, 'SelfTest': SelfTest, 'Menu': Menu, 'Settings': Settings, 'PSV': PSV, 'PCV': PCV};

jeb.animator.init = function() {
    $anim.canvas.width = 1500;
    $anim.canvas.height = 500;
    $anim.canvas.style.display = '';

    canvas = new fabric.Canvas("jeb.ui.animator");

    /* Works
    var defy = 225; // default Y 
    var Off = new State('Off', 50, defy);
    addState(Off);
    */

    /*
    var defy = 225; // default Y 
    var Off = new State('Off', 50, defy);
    var StartUp = new State('StartUp', 200, defy);
    var Start = new State('Start', 350, defy);
    var SelfTest = new State('SelfTest', 500, 275);
    var Menu = new State('State', 750, defy);
    var Settings = new State('Settings', 875, defy);
    var PSV = new State('PSV', 1000, 50);
    var PCV = new State('PCV', 1000, 350);
    */
    
    link(Off, StartUp);
    var midPoint = {x: SelfTest.left, y:PSV.top+PSV.height};
    curveLink(Off, PSV, midPoint);
    midPoint = {x: SelfTest.left, y:PCV.top+2*PCV.height};
    curveLink(Off, PCV, midPoint);

    link(StartUp, Start);
    midPoint = {x:Start.left, y:Start.top - 10};
    curveLink(StartUp, PSV, midPoint);
    midPoint = {x: SelfTest.left+SelfTest.width, y:SelfTest.top+3*SelfTest.height};
    curveLink(StartUp, PCV, midPoint);

    link(Start, Menu);
    link(Start, SelfTest);

    link(SelfTest, Menu);
    selfLoop(SelfTest);

    bilink(Menu, Settings);
    bilink(Menu, PSV);
    bilink(Menu, PCV);

    bilink(Settings, PSV);
    bilink(Settings, PCV);

    bilink(PSV, PCV, 'DOWN', 'UP');
    selfLoop(PSV);
    selfLoop(PCV);
    
    addStates(Off, StartUp, Start, SelfTest, Menu, Settings, PSV, PCV);
    //lightState(Off);
    canvas.renderAll();



}

jeb.animator.draw = function() {
    //ADD ANIMATION HERE
    // for debugging: console.log($var.modeG);

    // TODO : finish. Uncomplete, because sometimes the previous state
    // remains lighted. Seems that occurs on fails or crashes. Probably 
    // because modeGP is not modified in some cases. 
    // DONE : variable previousState (initially null) records the from state, 
    // whatever the modeGP value

    if (previousState != null)
        unlightState(previousState);
    lightState(stateVar[$var.modeG.value]);
//    if ($var.modeG.value != $var.modeGP.value)
//        unlightState(stateVar[$var.modeGP.value]);
    previousState = stateVar[$var.modeG.value];
    /*
    if ($var.modeG.value == $cst.Off) {
        lightState(stateVar[$var.modeG.value]);

    }
    
    if ($var.modeG.value == $cst.StartUp)
        lightState(StartUp);
    */

// works
//    if ($var.modeG.value == "Off")
//        lightState(Off);
    canvas.renderAll();
}

