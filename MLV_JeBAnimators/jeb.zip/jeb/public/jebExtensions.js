

class ParameterAssignmentManager
{

    static determineParameterType(inputValue)
    {
        let result
        // si c déjà une exp B on la laisse
        if (typeof inputValue === "string" && inputValue.trim().startsWith("$B(")) {
            return inputValue.trim(); // pas de guillemets
        }
        if(inputValue === "true")
        {
            result = "$B.TRUE"
        }
        else if(inputValue === "false")
        {
            result = "$B.FALSE"
        }
        else if(isNaN(parseFloat(inputValue)) === false)
        {
            result = "$B('"+inputValue+"')"
        }
        else 
        {
            result = "'"+inputValue+"'"
        }

        return result
    }

    static processInputAsScalar (inputValue, targetParameter)
    {
        let scalar = ParameterAssignmentManager.determineParameterType(inputValue)
        eval(targetParameter +" = " + scalar)
    }

    static processInputAsSet(inputValue, targetArray)
    {
        let success = false
        if(inputValue.includes(",") || inputValue.includes("{") || inputValue.includes("}"))
        {
            let arrayToImport = inputValue.split(",")
            arrayToImport = arrayToImport.map((value) =>{
                let result = value.trim()
                result = result.replace("{", "")
                result = result.replace("}", "")
                return ParameterAssignmentManager.determineParameterType(result)
            })

            arrayToImport =  arrayToImport.join()

            eval(targetArray + "= $B.SetExtension("+arrayToImport+")")

            success = true
        }
    
        return success
    }
}

class ConstantsAxiomsProcessor
{
    //Capture expressions like '$B.belong($cst.MAX_COF, $B.NATURAL1)' and return : $cst.MAX_COF and $B.NATURAL1
    static CAPTURE_TYPE = /\$B\.belong\(([.$a-zA-Z_1-9]+)+[, ]+([.$a-zA-Z_0-9()']+)[) ]+/g
    //Capture expressions like '$B.equal($cst.CoffeePrice, $B('50'))' and return : $cst.CoffeePrice and '50'
    static CAPTURE_VALUE = /\$B\.equal\(([.$a-zA-Z_1-9]+)+[, ]+\$B\(\'([0-9]+)\'\)[) ]+/g

    //Capture Set constants and all elements from set
    static CAPTURE_SET_CONSTANT = /\$B\.partition\(([$.a-zA-Z0-9_]+)/g
    static CAPTURE_SET_ELEMENT = /\$B.SetExtension\([$_a-zA-Z0-9]+\.([a-zA-Z0-9_]+)\)/g

    

    constructor()
    {
        this.suggestedParameterMap = new Map()
    }

    buildSuggestionMap = ()=>
    {
        for(let axiom of Object.entries($axm))
        {
            let result = ConstantsAxiomsProcessor.CAPTURE_SET_CONSTANT.exec(axiom[1].formula)
            if(result !== null && result.length >= 2)
            {

                let setArray = []
                const matchList = axiom[1].formula.match(ConstantsAxiomsProcessor.CAPTURE_SET_ELEMENT)
                if(matchList !== null)
                {
                    for(let match of matchList)
                    {
                        let regexpr = new RegExp(ConstantsAxiomsProcessor.CAPTURE_SET_ELEMENT)
                        let setElement = regexpr.exec(match)
                        if(setElement !== null)
                        {
                            setArray.push(setElement[1])
                        }
                    }

                    this.suggestedParameterMap.set(result[1], setArray)
                }
                    
            }
            else 
            {
                let typeRegexpr = new RegExp(ConstantsAxiomsProcessor.CAPTURE_TYPE)
                result = typeRegexpr.exec(axiom[1].formula)

                 if(result !== null && result.length >= 3)
                {
                    if(this.suggestedParameterMap.get(result[1]) === undefined ||
                        (this.suggestedParameterMap.get(result[1]) !== undefined && result[2] !== undefined) )
                    {
                        this.suggestedParameterMap.set(result[1], result[2])
                    }
                    
                }
                else 
                {
                    let valueRegexpr = new RegExp(ConstantsAxiomsProcessor.CAPTURE_VALUE)
                    result = valueRegexpr.exec(axiom[1].formula)
                    if(result !== null && result.length >= 3)
                    {
                        if(this.suggestedParameterMap.get(result[1]) === undefined ||
                        (this.suggestedParameterMap.get(result[1]) !== undefined && result[2] !== undefined) )
                        {
                            this.suggestedParameterMap.set(result[1], result[2])
                        }
                    }
                }
            }
                
        }
    }

    getSuggestion = (constantKey) => {
        let suggestedValue = this.suggestedParameterMap.get(constantKey)
        let result = undefined

        if(["$B.INTEGER", "$B.NATURAL", "$B.NATURAL1"].includes(suggestedValue))
        {
            result = "" // $B.UpTo($B('1'), $B('999')).anyMember()
        }
        else if (suggestedValue === "$B.BOOL")
        {
            result = $B.BOOL.anyMember()
        }
        else if(/\$B\(\'\d+\'\)/.test(suggestedValue))
        {
            result = suggestedValue
        }
        else if(isNaN(parseFloat(suggestedValue)) === false)
        {
            result = suggestedValue
        }
        else if(typeof(suggestedValue) === "object")
        {
            result = suggestedValue
        }
        else
        {
            result = constantKey.replace("$cst.", "")
        }

        return result
    }


}


class MissingConstantsModal
{
    constructor()
    {
        this.modalCancelButton = document.getElementById("modal-cancel-btn")
        this.modalCancelButton.addEventListener("click", this.hideModal)

        this.modalSubmitButton = document.getElementById("modal-submit-btn")
        this.modalSubmitButton.addEventListener("click", this.assignConstants)

        this.modalImportButton = document.getElementById("modal-import-json-btn")
        if (this.modalImportButton) {
            this.modalImportButton.addEventListener("click", this.triggerFileImport)
        }

        this.modalFileInput = document.getElementById("modal-json-file-input")
        if (this.modalFileInput) {
            this.modalFileInput.addEventListener("change", this.handleJSONImport)
        }

        this.importedJsonData = null
    }

    hideModal = ()=>
    {
        const modalElement = document.querySelector(".modal")
        const overlayElement = document.querySelector(".overlay")

        modalElement.classList.add("hidden")
        overlayElement.classList.add("hidden")
    }

    showModal = ()=>
    {
        const modalElement = document.querySelector(".modal")
        const overlayElement = document.querySelector(".overlay")

        modalElement.classList.remove("hidden")
        overlayElement.classList.remove("hidden")
    }

    addModalInput = (label, inputIndex) =>
    {
        setTimeout(() => {
            const labelElement = document.createElement("label")
            labelElement.innerText=label
            const inputElement = document.createElement("input")
            inputElement.id = "modal-constant-"+inputIndex
            inputElement.setAttribute("data-constant-name", label)
            inputElement.value = $constantAxiomsProcessor.getSuggestion(label)
            const divElement = document.createElement("div")
            const modalDivElement = document.getElementById("modal-div")
            divElement.appendChild(labelElement)
            divElement.appendChild(inputElement)
            modalDivElement.appendChild(divElement)
        }, 100)
    }

    triggerFileImport = () => {
        if (this.modalFileInput) {
            this.modalFileInput.click()
        }
    }

    handleJSONImport = (event) => {
        const file = event.target.files[0]
        if (!file) return

        const reader = new FileReader()
        reader.onload = (e) => {
            try {
                const jsonData = JSON.parse(e.target.result)
                this.fillConstantsFromJSON(jsonData)
            } catch (error) {
                alert("Error reading JSON file: " + error.message)
                console.error("JSON parse error:", error)
            }
        }
        reader.readAsText(file)
    }

    fillConstantsFromJSON = (jsonData) => {
        this.importedJsonData = jsonData

        const setupConstants = jsonData.transitionList?.find(
            transition => transition.name === "$setup_constants"
        )

        if (!setupConstants || !setupConstants.destState) {
            alert("No constants found in JSON file (missing $setup_constants)")
            return
        }

        console.log("Constants found in JSON:", setupConstants.destState)

        let filledCount = 0
        for (let i = 0, len = jeb.__constants.length; i < len; i++) {
            const inputElement = document.getElementById("modal-constant-" + i)
            if (inputElement) {
                const constantName = inputElement.getAttribute("data-constant-name")
                const shortName = constantName.replace("$cst.", "")

                // Only import constants that start with MAX_
                if (!shortName.startsWith("MAX_")) {
                    continue
                }

                let value = setupConstants.destState[constantName] ||
                           setupConstants.destState[shortName]

                if (value !== undefined) {
                    if (typeof value === 'object' && Array.isArray(value)) {
                        inputElement.value = "{" + value.join(", ") + "}"
                    } else if (typeof value === 'string' && value.startsWith("$B(")) {
                        const match = value.match(/\$B\('(.+?)'\)/)
                        inputElement.value = match ? match[1] : value
                    } else {
                        inputElement.value = value
                    }
                    filledCount++
                } else {
                    console.warn("Constant not found in JSON:", constantName)
                }
            }
        }

        console.log(filledCount + " constant(s) imported from JSON")
        this.assignConstantsAndReplay()
    }

    assignConstantsAndReplay = () => {
        try {
            for(let i = 0, len = jeb.__constants.length; i < len; i++) {
                let inputValue = document.getElementById("modal-constant-"+i).value
                if(ParameterAssignmentManager.processInputAsSet(inputValue, jeb.__constants[i]) === false) {
                    ParameterAssignmentManager.processInputAsScalar(inputValue, jeb.__constants[i])
                }
            }

            console.log("Constants assigned successfully")
        } catch(e) {
            console.error("Error assigning constants:", e.stack)
            alert("Error assigning constants: " + e.message)
            return
        }

        try {
            jeb.ui.initMachinePage()
        } catch(e) {
            try {
                jeb.ui.initContextPage()
            } catch(e2) {
                console.error("Error initializing page:", e2)
            }
        }

        this.hideModal()

        if (this.importedJsonData) {
            setTimeout(() => {
                console.log("Replaying scenario automatically...")

                try {
                    // reset recorder avant replay
                    if (window.scenarioRecorder) {
                        window.scenarioRecorder.reset();
                        const countElement = document.getElementById('scenario-event-count');
                        if (countElement) countElement.textContent = '(0 events recorded)';
                    }
                    const jsonTraceConverter = new JSONTraceConverter(this.importedJsonData)
                    jsonTraceConverter.buildExecutionList()
                    const jsonExecution = new JSONTraceExecutionManager(jsonTraceConverter.executionList)
                    jsonExecution.executeTrace()

                    console.log("Scenario replayed successfully")
                    alert("Scenario imported and replayed successfully")
                } catch(error) {
                    console.error("Error replaying scenario:", error)
                    alert("Error replaying scenario: " + error.message)
                }

                this.importedJsonData = null
            }, 800)
        }
    }

    assignConstants = () => {
        try {
            for(let i = 0, len = jeb.__constants.length; i < len; i++) {
                let inputValue = document.getElementById("modal-constant-"+i).value
                if(ParameterAssignmentManager.processInputAsSet(inputValue, jeb.__constants[i]) === false) {
                    ParameterAssignmentManager.processInputAsScalar(inputValue, jeb.__constants[i])
                }
            }
        } catch(e) {
            console.error(e.stack)
        }

        try {
            jeb.ui.initMachinePage()
        } catch(e) {
            jeb.ui.initContextPage()
        }

        this.hideModal()
    }
}



class JSONTraceParser
{
    constructor()
    {
        this.inputElement = document.getElementById("json-trace-input")
        if(this.inputElement !== null){
            this.inputElement.addEventListener("change", this.handleFileSelect)
        }

        this.importButton = document.getElementById("json-import-btn")
        if(this.importButton !== null){
            this.importButton.addEventListener("click", this.importJSON)
        }


        this.jsonTrace = null
        this.inputFileContent = ""
    }

    handleFileSelect = (event) => {
        const file = event.target.files[0]; // Sélectionne le premier fichier (l'utilisateur peut en sélectionner plusieurs mais ici on prend juste le premier)
    
        if (file) {
            const reader = new FileReader();
            
            // Écoute l'événement "load" qui se déclenche lorsque la lecture du fichier est terminée
            reader.onload = this.handleFileLoad.bind(this)
    
            // Lit le contenu du fichier en tant que texte
            reader.readAsText(file);
        }
    }

    handleFileLoad = (event) => {
        this.inputFileContent = event.target.result; // Contenu du fichier
    }

    importJSON = () => 
    {
        try
        {
            this.jsonTrace = JSON.parse(this.inputFileContent)
            // reset recorder avant replay
            if (window.scenarioRecorder) {
                window.scenarioRecorder.reset();
                const countElement = document.getElementById('scenario-event-count');
                if (countElement) countElement.textContent = '(0 events recorded)';
            }
            const jsonTraceConverter = new JSONTraceConverter(this.jsonTrace)
            jsonTraceConverter.buildExecutionList()
            const jsonExecution = new JSONTraceExecutionManager(jsonTraceConverter.executionList)
            jsonExecution.executeTrace()
        }
        catch(e)
        {
            console.error(e)
        }
    }
}

class JSONTraceConverter
{
    constructor(jsonTrace)
    {
        this.jsonTrace = jsonTrace
        this.executionList = []
    }

    buildExecutionList = () => {
        for(let transition of this.jsonTrace.transitionList)
        {
            for(let event of Object.entries($evt))
            {
                let execution = this.buildExecution(transition.name, event[1].label, event[1].id, transition.destState)
                if( execution !== null)
                {
                    this.executionList.push(execution)
                    const tParams = transition.params ?? transition.parameters; // supporte les 2 formats
                    if (tParams !== undefined && event[1].parameter !== undefined)
                    {
                        execution = this.addParamToExecution(execution, Object.entries(tParams), Object.entries(event[1].parameter))
                    }

                }
            }
        }

        this.executionList
    }

    buildExecution = (transitionName, eventName, eventId, destState) => {
        let execution = null
        if(transitionName === eventName)
        {
            execution = {
                id : eval(eventId),
                params : [],
                destState : destState || {}
            }
        }
        else if(transitionName === "$initialise_machine" && eventName === "INITIALISATION")
        {
            execution = {
                id : "INITIALISATION",
                params : [],
                destState : destState || {}
            }
        }

        return execution
    }

    addParamToExecution = (execution, transitionParams, eventParams) => {
        for(let param of transitionParams)
        {
            for(let evtParam of eventParams)
            {
                if(evtParam[0] === param[0])
                {
                    execution.params.push({id : evtParam[1].id, value: param[1]})
                }
            }
        }

        return execution
    }

}

class JSONTraceExecutionManager
{
    constructor(executionList)
    {
        this.executionList = executionList
    }

    withDestStateNondetResolver = (destState, callback) => {
        const origBecomesMemberOf = $B.becomesMemberOf;

        $B.becomesMemberOf = function (varRef, setRef) {
            try {
                const varName = (varRef && varRef.id) ? varRef.id.replace("$var.", "") : null;
                if (!varName || !destState || destState[varName] === undefined) {
                    return origBecomesMemberOf(varRef, setRef);
                }

                let wanted = destState[varName];
                if (typeof wanted !== "string") return origBecomesMemberOf(varRef, setRef);

                wanted = wanted.trim();

               // Cas valeurs numériques
                if (wanted.startsWith("$B(")) {
                    try {
                        return $B.becomesEqualTo([varRef], [eval(wanted)]);
                    } catch (e) {
                        return origBecomesMemberOf(varRef, setRef);
                    }
                }
                //  Cas constantes
                if (wanted.startsWith("$cst.")) wanted = wanted.slice(5);
                wanted = wanted.toLowerCase();

                if ($cst[wanted] !== undefined) {
                    return $B.becomesEqualTo([varRef], [$cst[wanted]]);
                }
                return origBecomesMemberOf(varRef, setRef);
            } catch(e) {
                return origBecomesMemberOf(varRef, setRef);
            }
        };

        try {
            return callback();
        } finally {
            $B.becomesMemberOf = origBecomesMemberOf;
        }
    }


    executeTrace = () => {

        jeb.scenario.variables = []
        jeb.scenario.parameters = [] 
        jeb.scenario.links = []
        jeb.ui.clearConsole()

        let selectedCSPSolver = ""

        if(jeb.ui.CSP_SOLVER !== "jeb-csp-only"){
            selectedCSPSolver = jeb.ui.CSP_SOLVER
            jeb.ui.CSP_SOLVER = "jeb-csp-only"
        }

        for (let execution of this.executionList)
        {
            const ds = execution.destState || {};

            if (execution.id === "INITIALISATION")
            {
                this.withDestStateNondetResolver(ds, () => {
                    jeb.scheduler.init();
                });
            }
            else
            {
                for (let param of execution.params)
                {
                    this.assignValueToParam(param);
                }

                this.withDestStateNondetResolver(ds, () => {
                    jeb.scheduler.execute(execution.id);
                });

                jeb.scheduler.testAllGuards();
            }
        }


        if(selectedCSPSolver !== ""){
            jeb.ui.CSP_SOLVER = selectedCSPSolver
        }
    }

    assignValueToParam = (param) =>
    {
        let valueToAssign = param.value.trim()

        if(ParameterAssignmentManager.processInputAsSet(valueToAssign, param.id+".value") === false)
        {
            ParameterAssignmentManager.processInputAsScalar(valueToAssign, param.id+".value")
        }
    }
}

class ProbcliConstraintBuilder
{
    static mathToAsciiCorrespondence = new Map()
    static bindedParametersArray = new Array()


    static formatConstraint(constraint)
    {
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.forEach((ascii, mathNotation) => {
            if(mathNotation === "·" && constraint.includes("·"))
            {
                constraint = constraint.replaceAll(mathNotation, ascii) + ")"
            }
            else
            {
                constraint = constraint.replaceAll(mathNotation, ascii)
            }        
        })

        return constraint
    }

    static checkIfConstraintOrVariable(elt, isVariable)
    {
        let value = ""
        if(isVariable)
        {
            value = elt[1].value
        }
        else
        {
            value = elt[1]
        }
        return value
    }

    static sortArray(arr, isArrayOfVariables)
    {
        let finalArr = []
        let nextArr1 = []
        let nextArr2 = []
        let nextArr3 = []

        arr.forEach((elt) => {
            let value = ProbcliConstraintBuilder.checkIfConstraintOrVariable(elt, isArrayOfVariables)

            if(Array.isArray(value) === true)
            {
                finalArr.push(elt)
            }
            else 
            {
                nextArr1.push(elt)
            }
        })

        nextArr1.forEach((elt)=>{
            let value = ProbcliConstraintBuilder.checkIfConstraintOrVariable(elt, isArrayOfVariables)

            if(value === "true" || value=== "false" || isNaN(parseFloat(value)) === false)
            {
                finalArr.push(elt)
            }
            else
            {
                nextArr2.push(elt)
            }
        })

        nextArr3 = nextArr2.sort((a, b) => {
            let valA = ProbcliConstraintBuilder.checkIfConstraintOrVariable(a, isArrayOfVariables)
            let valB = ProbcliConstraintBuilder.checkIfConstraintOrVariable(b, isArrayOfVariables)
            if(valA.length > valB.length){
                return 1
            } else if(valA.length < valB.length){
                return -1
            }
            return 0
        })

        finalArr.push(...nextArr3)

        return finalArr
    }

    static replaceByValue(arr, constraint, isArrayOfVariables)
    {
        let sortedList =  ProbcliConstraintBuilder.sortArray(arr)
        for(let elt of sortedList)
        {
            let name = elt[0]
            let value = ""
            if(isArrayOfVariables)
            {
                value = elt[1].value + ""
            }
            else
            {
                value = elt[1] + ""
            }

            if(Array.isArray(value) === true)
            {
                value = '{\\"' + value.join('\\",\\"') + '\\"}'
            }
            else if(value !== "true" && value !== "false" && isNaN(parseFloat(value)) !== false)
            {
                value = '\\"'+value+'\\"'
            }
            else if (value === "true" || value === "false")
            {
                value = value.toUpperCase()
            }
            constraint = constraint.replaceAll(name, value)
        }

        constraint = constraint.replaceAll(/\\"(\\")+/g,'\\"')
        return constraint
    }

    static replaceVariablesByValues(constraint)
    {
        return ProbcliConstraintBuilder.replaceByValue(Object.entries($var), constraint, true)
    }

    static replaceConstantsByValues(constraint)
    {
        return ProbcliConstraintBuilder.replaceByValue(Object.entries($cst), constraint, false)
    }

    static bindParametersToConstraint(constraint, parameterObj)
    {
        let result = ""
        for(let parameterArr of Object.entries(parameterObj))
        {
            let parameterName = parameterArr[0]
            if(constraint.includes(parameterName))
            {
                if(result === "")
                {
                    result = parameterName
                }
                else
                {
                    result += ", "+parameterName
                }
                ProbcliConstraintBuilder.bindedParametersArray.push(parameterName)
            }
        }

        result = "{ "+result+ " | "+constraint+" }"
        console.log("bindParametersToConstraint RESULT", result, ProbcliConstraintBuilder.bindedParametersArray)
        return result
    }



    static initMathToAsciiCorrespondence()
    {
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⩥", "|>>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("▷", "|>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∪", "\\/")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∩", "/\\")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("↦", "|->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("→", "-->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⊄", "/<<:")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∉", "/:")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⇔", "<=>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⇒", "=>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∧", "&")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∀", "!")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∃", "#")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("≠", "/=")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("≥", ">=")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("≤", "<=")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⊂", "<<:")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⊆", "<:")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("", "<<->>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("", "<<->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("", "<->>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("↔", "<->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⤖", ">->>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⇸", "+->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⤔", ">+>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("↣", ">->")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⤀", "+>>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("↠", "->>")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∅", "{}")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∖", "\\")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("×", "**")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("", "<+")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⊗", "><")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∥", "||")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∼", "~")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⩤", "<<|")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("◁", "<|")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("λ", "%")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("‥", "..")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("·", ".(")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("+", "+")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("−", "-")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("^", "^")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∗", "*")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("÷", "/")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("≔", ":=")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set(":∈", "::")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set(":∣", ":|")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∈", ":")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∣", "|")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("↦", ",,")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("ℕ1", "NAT1")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("ℕ", "NAT")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("ℙ1", "POW1")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("ℙ", "POW")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("ℤ", "INT")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⋂", "INTER")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⋃", "UNION")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∨", "or")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("¬", "not")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⊤", "true")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("∘", "circ")
        ProbcliConstraintBuilder.mathToAsciiCorrespondence.set("⦂", "oftype")
    }
}

class ProbcliSuggestBuilder
{
    static processCSPSuggestion(suggestion)
    {
        let arrayToSelect = suggestion.split(",")
        let arraySuggest = arrayToSelect[Math.floor(Math.random()*arrayToSelect.length)]
        arraySuggest = arraySuggest.replaceAll(/[()]/g, "")
        arraySuggest = arraySuggest.split("|->")
        arraySuggest = arraySuggest.map((suggest) => {
    
            suggest = suggest.toLowerCase()
            return ParameterAssignmentManager.determineParameterType(suggest)
        })
        return arraySuggest
    }

    static bindCSPSuggestionToParameters(parameterObj, suggestionArr)
    {
        let suggestIndex = 0
        ProbcliConstraintBuilder.bindedParametersArray = new Set(ProbcliConstraintBuilder.bindedParametersArray)
        ProbcliConstraintBuilder.bindedParametersArray = Array.from(ProbcliConstraintBuilder.bindedParametersArray)

        ProbcliConstraintBuilder.bindedParametersArray.forEach((parameter) =>{
            if(parameterObj[parameter] !== undefined)
            {
                //console.log("bindCSPSuggestionToParamters LOOP", parameterObj, parameter, suggestionArr, suggestionArr[suggestIndex])
                parameterObj[parameter].value = eval(suggestionArr[suggestIndex])
                suggestIndex++
            }
        })

        //console.log("bindCSPSuggestionToParamters RESULT", parameterObj, ProbcliConstraintBuilder.bindedParametersArray)
    }
}


let cspSolverSelectorElement = document.getElementById("jeb.ui.CSP_SOLVER")
if(cspSolverSelectorElement !== null)
{
    cspSolverSelectorElement.addEventListener("change", (event) => {
        jeb.ui.CSP_SOLVER = event.target.value
    })
}

const $missingConstantsModal = new MissingConstantsModal()
const $constantAxiomsProcessor = new ConstantsAxiomsProcessor()
window.addEventListener("load", () => {
        $constantAxiomsProcessor.buildSuggestionMap()  
})

const $jsonTraceParser = new JSONTraceParser()
ProbcliConstraintBuilder.initMathToAsciiCorrespondence()
