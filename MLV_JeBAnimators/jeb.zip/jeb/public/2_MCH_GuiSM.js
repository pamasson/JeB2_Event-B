/******************************************************************************
 * MACHINE [2_MCH_GuiSM]
 * Generated at 2026/10/06 16:48:57
 * JeB translator version 0.6.5
 ******************************************************************************/

/* Variables */
$var.power = new jeb.lang.Variable( '$var.power' );
$var.onAC = new jeb.lang.Variable( '$var.onAC' );
$var.batLev = new jeb.lang.Variable( '$var.batLev' );
$var.switchover = new jeb.lang.Variable( '$var.switchover' );
$var.crashed = new jeb.lang.Variable( '$var.crashed' );
$var.modeG = new jeb.lang.Variable( '$var.modeG' );
$var.modeGP = new jeb.lang.Variable( '$var.modeGP' );
$var.curTime = new jeb.lang.Variable( '$var.curTime' );
$var.batFail = new jeb.lang.Variable( '$var.batFail' );

/* Invariants */
$inv.i1 = new jeb.lang.Invariant( '$inv.i1', 'inv1' );
$inv.i1.predicate = function() {
    return $B.and($B.belong($var.power.value, $B.BOOL), $B.belong($var.crashed.value, $B.BOOL), $B.belong($var.batLev.value, $cst.batteryRange), $B.belong($var.curTime.value, $B.NATURAL), $B.belong($var.batFail.value, $B.BOOL));
};

$inv.i2 = new jeb.lang.Invariant( '$inv.i2', 'inv2' );
$inv.i2.predicate = function() {
    return $B.equivalence($B.or($B.equal($var.crashed.value, $B.TRUE), $B.equal($var.power.value, $B.FALSE), $B.and($B.equal($var.onAC.value, $B.FALSE), $B.or($B.equal($var.switchover.value, $B.FALSE), $B.equal($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.TRUE)))), $B.equal($var.modeG.value, $cst.Off));
};

$inv.i3 = new jeb.lang.Invariant( '$inv.i3', 'inv3' );
$inv.i3.predicate = function() {
    return $B.and($B.belong($var.modeG.value, $cst.ModesG), $B.belong($var.modeGP.value, $cst.ModesG));
};

$inv.i4 = new jeb.lang.Invariant( '$inv.i4', 'inv4' );
$inv.i4.predicate = function() {
    return $B.implication($B.notEqual($var.modeGP.value, $var.modeG.value), $B.belong($B.Pair($var.modeGP.value, $var.modeG.value), $B.functionImage($cst.possTransG, $B.bool($B.and($B.equal($var.power.value, $B.TRUE), $B.equal($var.crashed.value, $B.FALSE), $B.or($B.equal($var.onAC.value, $B.TRUE), $B.and($B.equal($var.switchover.value, $B.TRUE), $B.greaterThan($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.FALSE))))))));
};

$inv.i5 = new jeb.lang.Invariant( '$inv.i5', 'inv5' );
$inv.i5.predicate = function() {
    return $B.implication($B.equal($var.modeG.value, $cst.Settings), $B.belong($var.modeGP.value, $B.setUnion($B.SetExtension($cst.Menu), $cst.Ventilation)));
};

/* Event [INITIALISATION] */
$evt.init = new jeb.lang.Event( '$evt.init', 'INITIALISATION' );

$evt.init.action.a1 = new jeb.lang.Action( '$evt.init.action.a1', 'act1', $evt.init );
$evt.init.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.power], [$B.FALSE]);
};

$evt.init.action.a2 = new jeb.lang.Action( '$evt.init.action.a2', 'act2', $evt.init );
$evt.init.action.a2.assignment = function( $arg ) {
    $B.becomesMemberOf($var.batLev, $cst.batteryRange);
};

$evt.init.action.a3 = new jeb.lang.Action( '$evt.init.action.a3', 'act3', $evt.init );
$evt.init.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.onAC], [$B.TRUE]);
};

$evt.init.action.a4 = new jeb.lang.Action( '$evt.init.action.a4', 'act4', $evt.init );
$evt.init.action.a4.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.switchover], [$B.TRUE]);
};

$evt.init.action.a5 = new jeb.lang.Action( '$evt.init.action.a5', 'act5', $evt.init );
$evt.init.action.a5.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.crashed], [$B.FALSE]);
};

$evt.init.action.a6 = new jeb.lang.Action( '$evt.init.action.a6', 'act6', $evt.init );
$evt.init.action.a6.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Off]);
};

$evt.init.action.a7 = new jeb.lang.Action( '$evt.init.action.a7', 'act7', $evt.init );
$evt.init.action.a7.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$cst.Off]);
};

$evt.init.action.a8 = new jeb.lang.Action( '$evt.init.action.a8', 'act8', $evt.init );
$evt.init.action.a8.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.curTime], [$B('0')]);
};

$evt.init.action.a9 = new jeb.lang.Action( '$evt.init.action.a9', 'act9', $evt.init );
$evt.init.action.a9.assignment = function( $arg ) {
    $B.becomesMemberOf($var.batFail, $B.BOOL);
};


/* Event [powerON] */
$evt.e1 = new jeb.lang.Event( '$evt.e1', 'powerON' );

$evt.e1.guard.g1 = new jeb.lang.Guard( '$evt.e1.guard.g1', 'grd1', $evt.e1, 0, 'power=FALSE' );
$evt.e1.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.power.value, $B.FALSE);
};

$evt.e1.guard.g2 = new jeb.lang.Guard( '$evt.e1.guard.g2', 'grd2', $evt.e1, 0, 'onAC=TRUE∨(switchover=TRUE∧batLev>0∧batFail=FALSE)' );
$evt.e1.guard.g2.predicate = function( $arg ) {
    return $B.or($B.equal($var.onAC.value, $B.TRUE), $B.and($B.equal($var.switchover.value, $B.TRUE), $B.greaterThan($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.FALSE)));
};

$evt.e1.action.a1 = new jeb.lang.Action( '$evt.e1.action.a1', 'act1', $evt.e1 );
$evt.e1.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.power], [$B.TRUE]);
};

$evt.e1.action.a2 = new jeb.lang.Action( '$evt.e1.action.a2', 'act2', $evt.e1 );
$evt.e1.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$B.functionImage($B.SetExtension($B.Pair($B.FALSE, $cst.StartUp), $B.Pair($B.TRUE, $cst.Off)), $var.crashed.value)]);
};

$evt.e1.action.a3 = new jeb.lang.Action( '$evt.e1.action.a3', 'act3', $evt.e1 );
$evt.e1.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [powerOff] */
$evt.e2 = new jeb.lang.Event( '$evt.e2', 'powerOff' );

$evt.e2.guard.g1 = new jeb.lang.Guard( '$evt.e2.guard.g1', 'grd1', $evt.e2, 0, 'power=TRUE' );
$evt.e2.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.power.value, $B.TRUE);
};

$evt.e2.action.a1 = new jeb.lang.Action( '$evt.e2.action.a1', 'act1', $evt.e2 );
$evt.e2.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.power], [$B.FALSE]);
};

$evt.e2.action.a2 = new jeb.lang.Action( '$evt.e2.action.a2', 'act2', $evt.e2 );
$evt.e2.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Off]);
};

$evt.e2.action.a3 = new jeb.lang.Action( '$evt.e2.action.a3', 'act3', $evt.e2 );
$evt.e2.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [startUpEndedGui] */
$evt.e3 = new jeb.lang.Event( '$evt.e3', 'startUpEndedGui' );

$evt.e3.parameter.modeg = new jeb.lang.Parameter( '$evt.e3.parameter.modeg', $evt.e3, 0 );
$evt.e3.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e3.guard.g1 = new jeb.lang.Guard( '$evt.e3.guard.g1', 'grd1', $evt.e3, 0, 'modeG=StartUp' );
$evt.e3.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.modeG.value, $cst.StartUp);
};

$evt.e3.guard.g2 = new jeb.lang.Guard( '$evt.e3.guard.g2', 'grd2', $evt.e3, 1, 'modeg∈{Start}∪Ventilation' );
$evt.e3.guard.g2.predicate = function( $arg ) {
    return $B.belong($arg.modeg.value, $B.setUnion($B.SetExtension($cst.Start), $cst.Ventilation));
};

$evt.e3.action.a1 = new jeb.lang.Action( '$evt.e3.action.a1', 'act1', $evt.e3 );
$evt.e3.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e3.action.a2 = new jeb.lang.Action( '$evt.e3.action.a2', 'act2', $evt.e3 );
$evt.e3.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [crash] */
$evt.e4 = new jeb.lang.Event( '$evt.e4', 'crash' );

$evt.e4.guard.g1 = new jeb.lang.Guard( '$evt.e4.guard.g1', 'grd1', $evt.e4, 0, 'crashed=FALSE' );
$evt.e4.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.crashed.value, $B.FALSE);
};

$evt.e4.action.a1 = new jeb.lang.Action( '$evt.e4.action.a1', 'act1', $evt.e4 );
$evt.e4.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.crashed], [$B.TRUE]);
};

$evt.e4.action.a2 = new jeb.lang.Action( '$evt.e4.action.a2', 'act2', $evt.e4 );
$evt.e4.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Off]);
};

$evt.e4.action.a3 = new jeb.lang.Action( '$evt.e4.action.a3', 'act3', $evt.e4 );
$evt.e4.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$cst.Off]);
};


/* Event [repare] */
$evt.e5 = new jeb.lang.Event( '$evt.e5', 'repare' );

$evt.e5.parameter.modeg = new jeb.lang.Parameter( '$evt.e5.parameter.modeg', $evt.e5, 0 );
$evt.e5.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e5.guard.g1 = new jeb.lang.Guard( '$evt.e5.guard.g1', 'grd1', $evt.e5, 0, 'crashed=TRUE' );
$evt.e5.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.crashed.value, $B.TRUE);
};

$evt.e5.guard.g2 = new jeb.lang.Guard( '$evt.e5.guard.g2', 'grd2', $evt.e5, 1, 'power=FALSE∨(onAC=FALSE∧(switchover=FALSE∨batLev=0∨batFail=TRUE))⇒modeg=Off' );
$evt.e5.guard.g2.predicate = function( $arg ) {
    return $B.implication($B.or($B.equal($var.power.value, $B.FALSE), $B.and($B.equal($var.onAC.value, $B.FALSE), $B.or($B.equal($var.switchover.value, $B.FALSE), $B.equal($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.TRUE)))), $B.equal($arg.modeg.value, $cst.Off));
};

$evt.e5.guard.g3 = new jeb.lang.Guard( '$evt.e5.guard.g3', 'grd3', $evt.e5, 1, 'power=TRUE∧(onAC=TRUE∨(switchover=TRUE∧batLev>0∧batFail=FALSE))⇒modeg=StartUp' );
$evt.e5.guard.g3.predicate = function( $arg ) {
    return $B.implication($B.and($B.equal($var.power.value, $B.TRUE), $B.or($B.equal($var.onAC.value, $B.TRUE), $B.and($B.equal($var.switchover.value, $B.TRUE), $B.greaterThan($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.FALSE)))), $B.equal($arg.modeg.value, $cst.StartUp));
};

$evt.e5.action.a1 = new jeb.lang.Action( '$evt.e5.action.a1', 'act1', $evt.e5 );
$evt.e5.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.crashed], [$B.FALSE]);
};

$evt.e5.action.a2 = new jeb.lang.Action( '$evt.e5.action.a2', 'act2', $evt.e5 );
$evt.e5.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e5.action.a3 = new jeb.lang.Action( '$evt.e5.action.a3', 'act3', $evt.e5 );
$evt.e5.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [newPatient] */
$evt.e6 = new jeb.lang.Event( '$evt.e6', 'newPatient' );

$evt.e6.guard.g1 = new jeb.lang.Guard( '$evt.e6.guard.g1', 'grd1', $evt.e6, 0, 'modeG=Start' );
$evt.e6.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.modeG.value, $cst.Start);
};

$evt.e6.action.a1 = new jeb.lang.Action( '$evt.e6.action.a1', 'act1', $evt.e6 );
$evt.e6.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.SelfTest]);
};

$evt.e6.action.a2 = new jeb.lang.Action( '$evt.e6.action.a2', 'act2', $evt.e6 );
$evt.e6.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [resumeVent] */
$evt.e7 = new jeb.lang.Event( '$evt.e7', 'resumeVent' );

$evt.e7.guard.g1 = new jeb.lang.Guard( '$evt.e7.guard.g1', 'grd1', $evt.e7, 0, 'modeG=Start' );
$evt.e7.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.modeG.value, $cst.Start);
};

$evt.e7.action.a1 = new jeb.lang.Action( '$evt.e7.action.a1', 'act1', $evt.e7 );
$evt.e7.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Menu]);
};

$evt.e7.action.a2 = new jeb.lang.Action( '$evt.e7.action.a2', 'act2', $evt.e7 );
$evt.e7.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [runAbortSelfTest] */
$evt.e8 = new jeb.lang.Event( '$evt.e8', 'runAbortSelfTest' );

$evt.e8.guard.g1 = new jeb.lang.Guard( '$evt.e8.guard.g1', 'grd1', $evt.e8, 0, 'modeG=SelfTest' );
$evt.e8.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.modeG.value, $cst.SelfTest);
};

$evt.e8.action.a1 = new jeb.lang.Action( '$evt.e8.action.a1', 'act1', $evt.e8 );
$evt.e8.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.SelfTest]);
};

$evt.e8.action.a2 = new jeb.lang.Action( '$evt.e8.action.a2', 'act2', $evt.e8 );
$evt.e8.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [selfTestPassed] */
$evt.e9 = new jeb.lang.Event( '$evt.e9', 'selfTestPassed' );

$evt.e9.guard.g1 = new jeb.lang.Guard( '$evt.e9.guard.g1', 'grd1', $evt.e9, 0, 'modeG=SelfTest' );
$evt.e9.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.modeG.value, $cst.SelfTest);
};

$evt.e9.action.a1 = new jeb.lang.Action( '$evt.e9.action.a1', 'act1', $evt.e9 );
$evt.e9.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Menu]);
};

$evt.e9.action.a2 = new jeb.lang.Action( '$evt.e9.action.a2', 'act2', $evt.e9 );
$evt.e9.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [setParam] */
$evt.e10 = new jeb.lang.Event( '$evt.e10', 'setParam' );

$evt.e10.guard.g1 = new jeb.lang.Guard( '$evt.e10.guard.g1', 'grd1', $evt.e10, 0, 'modeG∈{Menu}∪Ventilation' );
$evt.e10.guard.g1.predicate = function( $arg ) {
    return $B.belong($var.modeG.value, $B.setUnion($B.SetExtension($cst.Menu), $cst.Ventilation));
};

$evt.e10.action.a1 = new jeb.lang.Action( '$evt.e10.action.a1', 'act1', $evt.e10 );
$evt.e10.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$cst.Settings]);
};

$evt.e10.action.a2 = new jeb.lang.Action( '$evt.e10.action.a2', 'act2', $evt.e10 );
$evt.e10.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [saveBackAbort] */
$evt.e11 = new jeb.lang.Event( '$evt.e11', 'saveBackAbort' );

$evt.e11.parameter.modeg = new jeb.lang.Parameter( '$evt.e11.parameter.modeg', $evt.e11, 0 );
$evt.e11.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e11.guard.g1 = new jeb.lang.Guard( '$evt.e11.guard.g1', 'grd1', $evt.e11, 1, 'modeG=Settings∧modeg∈ModesG' );
$evt.e11.guard.g1.predicate = function( $arg ) {
    return $B.and($B.equal($var.modeG.value, $cst.Settings), $B.belong($arg.modeg.value, $cst.ModesG));
};

$evt.e11.guard.g2 = new jeb.lang.Guard( '$evt.e11.guard.g2', 'grd2', $evt.e11, 1, 'modeg∈Ventilation∪{Menu}' );
$evt.e11.guard.g2.predicate = function( $arg ) {
    return $B.belong($arg.modeg.value, $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Menu)));
};

$evt.e11.action.a1 = new jeb.lang.Action( '$evt.e11.action.a1', 'act1', $evt.e11 );
$evt.e11.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e11.action.a2 = new jeb.lang.Action( '$evt.e11.action.a2', 'act2', $evt.e11 );
$evt.e11.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [startStopPCVPSV] */
$evt.e12 = new jeb.lang.Event( '$evt.e12', 'startStopPCVPSV' );

$evt.e12.parameter.modeg = new jeb.lang.Parameter( '$evt.e12.parameter.modeg', $evt.e12, 0 );
$evt.e12.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e12.guard.g1 = new jeb.lang.Guard( '$evt.e12.guard.g1', 'grd1', $evt.e12, 0, 'modeG∈{Menu}∪Ventilation' );
$evt.e12.guard.g1.predicate = function( $arg ) {
    return $B.belong($var.modeG.value, $B.setUnion($B.SetExtension($cst.Menu), $cst.Ventilation));
};

$evt.e12.guard.g2 = new jeb.lang.Guard( '$evt.e12.guard.g2', 'grd2', $evt.e12, 1, 'modeg∈Ventilation∪{Menu}' );
$evt.e12.guard.g2.predicate = function( $arg ) {
    return $B.belong($arg.modeg.value, $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Menu)));
};

$evt.e12.guard.g3 = new jeb.lang.Guard( '$evt.e12.guard.g3', 'grd3', $evt.e12, 1, 'modeG=Menu⇒modeg∈Ventilation' );
$evt.e12.guard.g3.predicate = function( $arg ) {
    return $B.implication($B.equal($var.modeG.value, $cst.Menu), $B.belong($arg.modeg.value, $cst.Ventilation));
};

$evt.e12.guard.g4 = new jeb.lang.Guard( '$evt.e12.guard.g4', 'grd4', $evt.e12, 1, 'modeG∈Ventilation⇒modeg=Menu' );
$evt.e12.guard.g4.predicate = function( $arg ) {
    return $B.implication($B.belong($var.modeG.value, $cst.Ventilation), $B.equal($arg.modeg.value, $cst.Menu));
};

$evt.e12.action.a1 = new jeb.lang.Action( '$evt.e12.action.a1', 'act1', $evt.e12 );
$evt.e12.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e12.action.a2 = new jeb.lang.Action( '$evt.e12.action.a2', 'act2', $evt.e12 );
$evt.e12.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [changeMode] */
$evt.e13 = new jeb.lang.Event( '$evt.e13', 'changeMode' );

$evt.e13.parameter.modeg = new jeb.lang.Parameter( '$evt.e13.parameter.modeg', $evt.e13, 0 );
$evt.e13.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e13.guard.g1 = new jeb.lang.Guard( '$evt.e13.guard.g1', 'grd1', $evt.e13, 0, 'modeG∈Ventilation' );
$evt.e13.guard.g1.predicate = function( $arg ) {
    return $B.belong($var.modeG.value, $cst.Ventilation);
};

$evt.e13.guard.g2 = new jeb.lang.Guard( '$evt.e13.guard.g2', 'grd2', $evt.e13, 1, 'modeg∈Ventilation∪{Settings}' );
$evt.e13.guard.g2.predicate = function( $arg ) {
    return $B.belong($arg.modeg.value, $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Settings)));
};

$evt.e13.action.a1 = new jeb.lang.Action( '$evt.e13.action.a1', 'act1', $evt.e13 );
$evt.e13.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e13.action.a2 = new jeb.lang.Action( '$evt.e13.action.a2', 'act2', $evt.e13 );
$evt.e13.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$var.modeG.value]);
};


/* Event [failExternalPower] */
$evt.e14 = new jeb.lang.Event( '$evt.e14', 'failExternalPower' );

$evt.e14.parameter.modegp = new jeb.lang.Parameter( '$evt.e14.parameter.modegp', $evt.e14, 0 );
$evt.e14.parameter.modeg = new jeb.lang.Parameter( '$evt.e14.parameter.modeg', $evt.e14, 0 );
$evt.e14.bindArguments = function( $arg ) {
    $arg.modegp.value = jeb.ui.parseArgument($arg.modegp.domNodeInput.value);
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e14.guard.g1 = new jeb.lang.Guard( '$evt.e14.guard.g1', 'grd1', $evt.e14, 0, 'onAC=TRUE' );
$evt.e14.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.onAC.value, $B.TRUE);
};

$evt.e14.guard.g2 = new jeb.lang.Guard( '$evt.e14.guard.g2', 'grd2', $evt.e14, 1, 'modeg∈ModesG∧modegp∈ModesG' );
$evt.e14.guard.g2.predicate = function( $arg ) {
    return $B.and($B.belong($arg.modeg.value, $cst.ModesG), $B.belong($arg.modegp.value, $cst.ModesG));
};

$evt.e14.guard.g3 = new jeb.lang.Guard( '$evt.e14.guard.g3', 'grd3', $evt.e14, 1, '¬(power=TRUE∧crashed=FALSE)⇒modeg=Off∧modegp=Off' );
$evt.e14.guard.g3.predicate = function( $arg ) {
    return $B.implication($B.not($B.and($B.equal($var.power.value, $B.TRUE), $B.equal($var.crashed.value, $B.FALSE))), $B.and($B.equal($arg.modeg.value, $cst.Off), $B.equal($arg.modegp.value, $cst.Off)));
};

$evt.e14.guard.g4 = new jeb.lang.Guard( '$evt.e14.guard.g4', 'grd4', $evt.e14, 1, 'power=TRUE∧crashed=FALSE⇒(switchover=TRUE∧batLev>0∧batFail=FALSE⇒modeg=modeG∧modegp=modeGP)∧(¬(switchover=TRUE∧batLev>0∧batFail=FALSE)⇒modeg=Off∧modegp=modeG)' );
$evt.e14.guard.g4.predicate = function( $arg ) {
    return $B.implication($B.and($B.equal($var.power.value, $B.TRUE), $B.equal($var.crashed.value, $B.FALSE)), $B.and($B.implication($B.and($B.equal($var.switchover.value, $B.TRUE), $B.greaterThan($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.FALSE)), $B.and($B.equal($arg.modeg.value, $var.modeG.value), $B.equal($arg.modegp.value, $var.modeGP.value))), $B.implication($B.not($B.and($B.equal($var.switchover.value, $B.TRUE), $B.greaterThan($var.batLev.value, $B('0')), $B.equal($var.batFail.value, $B.FALSE))), $B.and($B.equal($arg.modeg.value, $cst.Off), $B.equal($arg.modegp.value, $var.modeG.value)))));
};

$evt.e14.action.a1 = new jeb.lang.Action( '$evt.e14.action.a1', 'act1', $evt.e14 );
$evt.e14.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.onAC], [$B.FALSE]);
};

$evt.e14.action.a2 = new jeb.lang.Action( '$evt.e14.action.a2', 'act2', $evt.e14 );
$evt.e14.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e14.action.a3 = new jeb.lang.Action( '$evt.e14.action.a3', 'act3', $evt.e14 );
$evt.e14.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$arg.modegp.value]);
};


/* Event [progress] */
$evt.e15 = new jeb.lang.Event( '$evt.e15', 'progress' );

$evt.e15.parameter.l = new jeb.lang.Parameter( '$evt.e15.parameter.l', $evt.e15, 0 );
$evt.e15.parameter.modeg = new jeb.lang.Parameter( '$evt.e15.parameter.modeg', $evt.e15, 0 );
$evt.e15.parameter.step = new jeb.lang.Parameter( '$evt.e15.parameter.step', $evt.e15, 0 );
$evt.e15.parameter.batf = new jeb.lang.Parameter( '$evt.e15.parameter.batf', $evt.e15, 0 );
$evt.e15.bindArguments = function( $arg ) {
    $arg.l.value = jeb.ui.parseArgument($arg.l.domNodeInput.value);
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
    $arg.step.value = jeb.ui.parseArgument($arg.step.domNodeInput.value);
    $arg.batf.value = jeb.ui.parseArgument($arg.batf.domNodeInput.value);
};

$evt.e15.guard.g1 = new jeb.lang.Guard( '$evt.e15.guard.g1', 'grd1', $evt.e15, 1, 'step∈ℕ1∧l∈batteryRange∧batf∈BOOL' );
$evt.e15.guard.g1.predicate = function( $arg ) {
    return $B.and($B.belong($arg.step.value, $B.NATURAL1), $B.belong($arg.l.value, $cst.batteryRange), $B.belong($arg.batf.value, $B.BOOL));
};

$evt.e15.guard.g2 = new jeb.lang.Guard( '$evt.e15.guard.g2', 'grd2', $evt.e15, 1, 'batFail=TRUE⇒l=batLev' );
$evt.e15.guard.g2.predicate = function( $arg ) {
    return $B.implication($B.equal($var.batFail.value, $B.TRUE), $B.equal($arg.l.value, $var.batLev.value));
};

$evt.e15.guard.g3 = new jeb.lang.Guard( '$evt.e15.guard.g3', 'grd3', $evt.e15, 1, 'onAC=TRUE∧batFail=FALSE⇔l=batLev+step' );
$evt.e15.guard.g3.predicate = function( $arg ) {
    return $B.equivalence($B.and($B.equal($var.onAC.value, $B.TRUE), $B.equal($var.batFail.value, $B.FALSE)), $B.equal($arg.l.value, $B.plus($var.batLev.value, $arg.step.value)));
};

$evt.e15.guard.g4 = new jeb.lang.Guard( '$evt.e15.guard.g4', 'grd4', $evt.e15, 1, 'onAC=FALSE∧batFail=FALSE⇔l=max({0,batLev − step})' );
$evt.e15.guard.g4.predicate = function( $arg ) {
    return $B.equivalence($B.and($B.equal($var.onAC.value, $B.FALSE), $B.equal($var.batFail.value, $B.FALSE)), $B.equal($arg.l.value, $B.max($B.SetExtension($B('0'), $B.minus($var.batLev.value ,$arg.step.value)))));
};

$evt.e15.guard.g5 = new jeb.lang.Guard( '$evt.e15.guard.g5', 'grd5', $evt.e15, 1, '(onAC=TRUE∨(l>0∧switchover=TRUE∧batf=FALSE))∧power=TRUE∧modeG=Off∧crashed=FALSE⇒modeg=StartUp' );
$evt.e15.guard.g5.predicate = function( $arg ) {
    return $B.implication($B.and($B.or($B.equal($var.onAC.value, $B.TRUE), $B.and($B.greaterThan($arg.l.value, $B('0')), $B.equal($var.switchover.value, $B.TRUE), $B.equal($arg.batf.value, $B.FALSE))), $B.equal($var.power.value, $B.TRUE), $B.equal($var.modeG.value, $cst.Off), $B.equal($var.crashed.value, $B.FALSE)), $B.equal($arg.modeg.value, $cst.StartUp));
};

$evt.e15.guard.g6 = new jeb.lang.Guard( '$evt.e15.guard.g6', 'grd6', $evt.e15, 1, '(l=0∨batf=TRUE∨switchover=FALSE)∧onAC=FALSE⇒modeg=Off' );
$evt.e15.guard.g6.predicate = function( $arg ) {
    return $B.implication($B.and($B.or($B.equal($arg.l.value, $B('0')), $B.equal($arg.batf.value, $B.TRUE), $B.equal($var.switchover.value, $B.FALSE)), $B.equal($var.onAC.value, $B.FALSE)), $B.equal($arg.modeg.value, $cst.Off));
};

$evt.e15.guard.g7 = new jeb.lang.Guard( '$evt.e15.guard.g7', 'grd7', $evt.e15, 1, 'onAC=TRUE∨((l>0∧batLev>0)∧switchover=TRUE∧batf=FALSE)⇒modeg=modeG' );
$evt.e15.guard.g7.predicate = function( $arg ) {
    return $B.implication($B.or($B.equal($var.onAC.value, $B.TRUE), $B.and($B.and($B.greaterThan($arg.l.value, $B('0')), $B.greaterThan($var.batLev.value, $B('0'))), $B.equal($var.switchover.value, $B.TRUE), $B.equal($arg.batf.value, $B.FALSE))), $B.equal($arg.modeg.value, $var.modeG.value));
};

$evt.e15.action.a1 = new jeb.lang.Action( '$evt.e15.action.a1', 'act1', $evt.e15 );
$evt.e15.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.curTime], [$B.plus($var.curTime.value, $arg.step.value)]);
};

$evt.e15.action.a2 = new jeb.lang.Action( '$evt.e15.action.a2', 'act2', $evt.e15 );
$evt.e15.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.batLev], [$arg.l.value]);
};

$evt.e15.action.a3 = new jeb.lang.Action( '$evt.e15.action.a3', 'act3', $evt.e15 );
$evt.e15.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e15.action.a4 = new jeb.lang.Action( '$evt.e15.action.a4', 'act4', $evt.e15 );
$evt.e15.action.a4.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$B.functionImage($B.SetExtension($B.Pair($B.TRUE, $var.modeGP.value), $B.Pair($B.FALSE, $var.modeG.value)), $B.bool($B.equal($arg.modeg.value, $var.modeG.value)))]);
};

$evt.e15.action.a5 = new jeb.lang.Action( '$evt.e15.action.a5', 'act5', $evt.e15 );
$evt.e15.action.a5.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.batFail], [$arg.batf.value]);
};


/* Event [switchoverFail] */
$evt.e16 = new jeb.lang.Event( '$evt.e16', 'switchoverFail' );

$evt.e16.parameter.modeg = new jeb.lang.Parameter( '$evt.e16.parameter.modeg', $evt.e16, 0 );
$evt.e16.bindArguments = function( $arg ) {
    $arg.modeg.value = jeb.ui.parseArgument($arg.modeg.domNodeInput.value);
};

$evt.e16.guard.g1 = new jeb.lang.Guard( '$evt.e16.guard.g1', 'grd1', $evt.e16, 0, 'switchover=TRUE' );
$evt.e16.guard.g1.predicate = function( $arg ) {
    return $B.equal($var.switchover.value, $B.TRUE);
};

$evt.e16.guard.g2 = new jeb.lang.Guard( '$evt.e16.guard.g2', 'grd2', $evt.e16, 1, 'onAC=FALSE⇒modeg=Off' );
$evt.e16.guard.g2.predicate = function( $arg ) {
    return $B.implication($B.equal($var.onAC.value, $B.FALSE), $B.equal($arg.modeg.value, $cst.Off));
};

$evt.e16.guard.g3 = new jeb.lang.Guard( '$evt.e16.guard.g3', 'grd3', $evt.e16, 1, 'onAC=TRUE⇒modeg=modeG' );
$evt.e16.guard.g3.predicate = function( $arg ) {
    return $B.implication($B.equal($var.onAC.value, $B.TRUE), $B.equal($arg.modeg.value, $var.modeG.value));
};

$evt.e16.action.a1 = new jeb.lang.Action( '$evt.e16.action.a1', 'act1', $evt.e16 );
$evt.e16.action.a1.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.switchover], [$B.FALSE]);
};

$evt.e16.action.a2 = new jeb.lang.Action( '$evt.e16.action.a2', 'act2', $evt.e16 );
$evt.e16.action.a2.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeG], [$arg.modeg.value]);
};

$evt.e16.action.a3 = new jeb.lang.Action( '$evt.e16.action.a3', 'act3', $evt.e16 );
$evt.e16.action.a3.assignment = function( $arg ) {
    $B.becomesEqualTo([$var.modeGP], [$B.functionImage($B.SetExtension($B.Pair($B.TRUE, $var.modeG.value), $B.Pair($B.FALSE, $var.modeGP.value)), $B.bool($B.notEqual($var.modeG.value, $arg.modeg.value)))]);
};


