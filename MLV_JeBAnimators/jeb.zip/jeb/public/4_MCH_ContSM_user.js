var get_modeg = function( eventId ) {
    if (eventId == $evt.e3) {
        return $B.setUnion($B.SetExtension($cst.Start), $cst.Ventilation).anyMember();
    }
    if (eventId == $evt.e6) {
        return $B.SetExtension($cst.Off, $cst.StartUp).anyMember();
        // PAM: OK or so : random choice among the possible values
    }
    if (eventId == $evt.e12 || eventId == $evt.e13 || eventId == $evt.e14) {
        return $B.setUnion($cst.Ventilation, $B.SetExtension($cst.Menu)).anyMember();
    }
    if (eventId == $evt.e15 || eventId == $evt.e18) {
        return $cst.ModesG.anyMember();
    }
    if (eventId == $evt.e17) {
        return $var.modeG.value; // copied from ProB
        // return $B.setUnion($B.SetExtension($cst.StartUp, $cst.Start, $cst.Menu, $cst.SelfTest, $cst.Settings, $cst.Off), $cst.Ventilation).anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }

};

var get_modegp = function( eventId ) {
    if (eventId == $evt.e15) {
        return $cst.ModesG.anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesG values)
    }
};


var get_modec = function( eventId ) {
    if (eventId == $evt.e12 || eventId == $evt.e13 || eventId == $evt.e14 || eventId == $evt.e15
        || eventId == $evt.e17 || eventId == $evt.e18) {
        return $cst.ModesC.anyMember();
    }
}

var get_modecp = function( eventId ) {
    if (eventId == $evt.e15) {
        return $cst.ModesC.anyMember();
        // PAM: OK or so : random choice among all the possible values (all ModesC values)
    }
}

// Auto-generated function: argument generator
var get_step = function( eventId ) {
    if (eventId == $evt.e17) {
        // PAM: in the model step : NAT1. I limit it to values 1,2, or 3. 
        return $B.UpTo($B('1'), $B('3')).anyMember();
        //return Math.ceil(Math.random()*5);
    }
};

// Auto-generated function: argument generator
var get_l = function( eventId ) {
    if (eventId == $evt.e17) {
        // PAM: return a random value chosen within the batteryRange (0..10)
        return $cst.batteryRange.anyMember();
        //return get_step(eventId);
    }
};

// Auto-generated function: argument generator
var get_batf = function( eventId ) {
    if (eventId == $evt.e17) {
        return $B.BOOL.anyMember();
        // PAM/ this one is OK
    }
};



jeb.animator.init = function() {
$anim.canvas.width = 1000;
$anim.canvas.height = 500;
$anim.canvas.style.display = '';
}

jeb.animator.draw = function() {
//ADD ANIMATION HERE
}

