/******************************************************************************
 * CONTEXT [3_CTX_ContStates]
 * Generated at 2026/10/06 16:48:57
 * JeB translator version 0.6.5
 ******************************************************************************/

/* Sets */

/* Constants */
$cst.ModesC;

$cst.FailSafe;

$cst.VentilationOff;

$cst.possTransC;


/* Axioms */
$axm.a7 = new jeb.lang.Axiom( '$axm.a7', 'axm1', "$B.partition($cst.Modes, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.Start), $B.SetExtension($cst.Menu), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.FailSafe), $B.SetExtension($cst.Settings), $B.SetExtension($cst.PSV), $B.SetExtension($cst.PCV), $B.SetExtension($cst.Off), $B.SetExtension($cst.VentilationOff))" );
$axm.a7.predicate = function() {
    return $B.partition($cst.Modes, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.Start), $B.SetExtension($cst.Menu), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.FailSafe), $B.SetExtension($cst.Settings), $B.SetExtension($cst.PSV), $B.SetExtension($cst.PCV), $B.SetExtension($cst.Off), $B.SetExtension($cst.VentilationOff));
};

$axm.a8 = new jeb.lang.Axiom( '$axm.a8', 'axm2', "$B.subset($cst.ModesC, $cst.Modes)" );
$axm.a8.predicate = function() {
    return $B.subset($cst.ModesC, $cst.Modes);
};

$axm.a9 = new jeb.lang.Axiom( '$axm.a9', 'axm3', "$B.partition($cst.ModesC, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.FailSafe), $B.SetExtension($cst.VentilationOff), $B.SetExtension($cst.Off), $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV))" );
$axm.a9.predicate = function() {
    return $B.partition($cst.ModesC, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.FailSafe), $B.SetExtension($cst.VentilationOff), $B.SetExtension($cst.Off), $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV));
};

$axm.a10 = new jeb.lang.Axiom( '$axm.a10', 'axm4', "$B.partition($cst.Ventilation, $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV))" );
$axm.a10.predicate = function() {
    return $B.partition($cst.Ventilation, $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV));
};

$axm.a11 = new jeb.lang.Axiom( '$axm.a11', 'axm5', "$B.belong($cst.possTransC, $B.TotalFunctions($B.BOOL, $B.PowerSet($B.CartesianProduct($cst.ModesC, $cst.ModesC))))" );
$axm.a11.predicate = function() {
    return $B.belong($cst.possTransC, $B.TotalFunctions($B.BOOL, $B.PowerSet($B.CartesianProduct($cst.ModesC, $cst.ModesC))));
};

$axm.a12 = new jeb.lang.Axiom( '$axm.a12', 'axm6', "$B.equal($cst.possTransC, $B.SetExtension($B.Pair($B.TRUE, $B.setUnion($B.SetExtension($B.Pair($cst.Off, $cst.StartUp), $B.Pair($cst.StartUp, $cst.SelfTest), $B.Pair($cst.StartUp, $cst.FailSafe), $B.Pair($cst.SelfTest, $cst.FailSafe), $B.Pair($cst.SelfTest, $cst.VentilationOff), $B.Pair($cst.VentilationOff, $cst.FailSafe), $B.Pair($cst.PSV, $cst.PCV), $B.Pair($cst.PCV, $cst.PSV)), $B.CartesianProduct($cst.Ventilation, $B.SetExtension($cst.VentilationOff)), $B.CartesianProduct($B.SetExtension($cst.VentilationOff), $cst.Ventilation), $B.CartesianProduct($cst.Ventilation, $B.SetExtension($cst.FailSafe)))), $B.Pair($B.FALSE, $B.CartesianProduct($B.setMinus($cst.ModesC, $B.SetExtension($cst.Off)), $B.SetExtension($cst.Off)))))" );
$axm.a12.predicate = function() {
    return $B.equal($cst.possTransC, $B.SetExtension($B.Pair($B.TRUE, $B.setUnion($B.SetExtension($B.Pair($cst.Off, $cst.StartUp), $B.Pair($cst.StartUp, $cst.SelfTest), $B.Pair($cst.StartUp, $cst.FailSafe), $B.Pair($cst.SelfTest, $cst.FailSafe), $B.Pair($cst.SelfTest, $cst.VentilationOff), $B.Pair($cst.VentilationOff, $cst.FailSafe), $B.Pair($cst.PSV, $cst.PCV), $B.Pair($cst.PCV, $cst.PSV)), $B.CartesianProduct($cst.Ventilation, $B.SetExtension($cst.VentilationOff)), $B.CartesianProduct($B.SetExtension($cst.VentilationOff), $cst.Ventilation), $B.CartesianProduct($cst.Ventilation, $B.SetExtension($cst.FailSafe)))), $B.Pair($B.FALSE, $B.CartesianProduct($B.setMinus($cst.ModesC, $B.SetExtension($cst.Off)), $B.SetExtension($cst.Off)))));
};


/* Cache constants */
jeb.__constants.push( '$cst.ModesC' );
jeb.__constants.push( '$cst.FailSafe' );
jeb.__constants.push( '$cst.VentilationOff' );
jeb.__constants.push( '$cst.possTransC' );
