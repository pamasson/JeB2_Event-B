/******************************************************************************
 * CONTEXT [1_CTX_GuiStates]
 * Generated at 2026/10/14 20:52:58
 * JeB translator version 0.6.5
 ******************************************************************************/

/* Sets */
$cst.Modes;


/* Constants */
$cst.ModesG;

$cst.StartUp;

$cst.Start;

$cst.SelfTest;

$cst.Menu;

$cst.Settings;

$cst.Ventilation;

$cst.Off;

$cst.possTransG;

$cst.PCV;

$cst.PSV;

$cst.batteryRange;


/* Axioms */
$axm.a1 = new jeb.lang.Axiom( '$axm.a1', 'axm1', "$B.subset($cst.ModesG, $cst.Modes)" );
$axm.a1.predicate = function() {
    return $B.subset($cst.ModesG, $cst.Modes);
};

$axm.a2 = new jeb.lang.Axiom( '$axm.a2', 'axm2', "$B.partition($cst.ModesG, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.Start), $B.SetExtension($cst.Menu), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.Settings), $cst.Ventilation, $B.SetExtension($cst.Off))" );
$axm.a2.predicate = function() {
    return $B.partition($cst.ModesG, $B.SetExtension($cst.StartUp), $B.SetExtension($cst.Start), $B.SetExtension($cst.Menu), $B.SetExtension($cst.SelfTest), $B.SetExtension($cst.Settings), $cst.Ventilation, $B.SetExtension($cst.Off));
};

$axm.a3 = new jeb.lang.Axiom( '$axm.a3', 'axm3', "$B.partition($cst.Ventilation, $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV))" );
$axm.a3.predicate = function() {
    return $B.partition($cst.Ventilation, $B.SetExtension($cst.PCV), $B.SetExtension($cst.PSV));
};

$axm.a4 = new jeb.lang.Axiom( '$axm.a4', 'axm4', "$B.belong($cst.possTransG, $B.TotalFunctions($B.BOOL, $B.PowerSet($B.CartesianProduct($cst.ModesG, $cst.ModesG))))" );
$axm.a4.predicate = function() {
    return $B.belong($cst.possTransG, $B.TotalFunctions($B.BOOL, $B.PowerSet($B.CartesianProduct($cst.ModesG, $cst.ModesG))));
};

$axm.a5 = new jeb.lang.Axiom( '$axm.a5', 'axm5', "$B.equal($cst.possTransG, $B.SetExtension($B.Pair($B.TRUE, $B.setUnion($B.SetExtension($B.Pair($cst.Off, $cst.StartUp), $B.Pair($cst.StartUp, $cst.Start)), $B.CartesianProduct($B.SetExtension($cst.StartUp), $cst.Ventilation), $B.SetExtension($B.Pair($cst.Start, $cst.Menu), $B.Pair($cst.Start, $cst.SelfTest), $B.Pair($cst.Menu, $cst.Settings), $B.Pair($cst.SelfTest, $cst.SelfTest), $B.Pair($cst.SelfTest, $cst.Menu), $B.Pair($cst.Settings, $cst.Menu)), $B.CartesianProduct($B.SetExtension($cst.Off), $cst.Ventilation), $B.CartesianProduct($B.SetExtension($cst.Menu, $cst.Settings), $cst.Ventilation), $B.CartesianProduct($cst.Ventilation, $B.setUnion($B.SetExtension($cst.Menu, $cst.Settings), $cst.Ventilation)))), $B.Pair($B.FALSE, $B.CartesianProduct($cst.ModesG, $B.SetExtension($cst.Off)))))" );
$axm.a5.predicate = function() {
    return $B.equal($cst.possTransG, $B.SetExtension($B.Pair($B.TRUE, $B.setUnion($B.SetExtension($B.Pair($cst.Off, $cst.StartUp), $B.Pair($cst.StartUp, $cst.Start)), $B.CartesianProduct($B.SetExtension($cst.StartUp), $cst.Ventilation), $B.SetExtension($B.Pair($cst.Start, $cst.Menu), $B.Pair($cst.Start, $cst.SelfTest), $B.Pair($cst.Menu, $cst.Settings), $B.Pair($cst.SelfTest, $cst.SelfTest), $B.Pair($cst.SelfTest, $cst.Menu), $B.Pair($cst.Settings, $cst.Menu)), $B.CartesianProduct($B.SetExtension($cst.Off), $cst.Ventilation), $B.CartesianProduct($B.SetExtension($cst.Menu, $cst.Settings), $cst.Ventilation), $B.CartesianProduct($cst.Ventilation, $B.setUnion($B.SetExtension($cst.Menu, $cst.Settings), $cst.Ventilation)))), $B.Pair($B.FALSE, $B.CartesianProduct($cst.ModesG, $B.SetExtension($cst.Off)))));
};

$axm.a6 = new jeb.lang.Axiom( '$axm.a6', 'axm6', "$B.equal($cst.batteryRange, $B.UpTo($B('0'), $B.multiply($B('120'), $B('60'), $B('10'))))" );
$axm.a6.predicate = function() {
    return $B.equal($cst.batteryRange, $B.UpTo($B('0'), $B.multiply($B('120'), $B('60'), $B('10'))));
};


/* Cache constants */
jeb.__constants.push( '$cst.Modes' );
jeb.__constants.push( '$cst.ModesG' );
jeb.__constants.push( '$cst.StartUp' );
jeb.__constants.push( '$cst.Start' );
jeb.__constants.push( '$cst.SelfTest' );
jeb.__constants.push( '$cst.Menu' );
jeb.__constants.push( '$cst.Settings' );
jeb.__constants.push( '$cst.Ventilation' );
jeb.__constants.push( '$cst.Off' );
jeb.__constants.push( '$cst.possTransG' );
jeb.__constants.push( '$cst.PCV' );
jeb.__constants.push( '$cst.PSV' );
jeb.__constants.push( '$cst.batteryRange' );
