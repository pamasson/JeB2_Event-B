npm init -y && npm install express
pause
